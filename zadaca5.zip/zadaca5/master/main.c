#define __AVR_ATmega328P__

#include <avr/io.h>
#include "FreeRTOS.h"
#include "task.h"
#include "serial.h"
#include "queue.h"
#include "semphr.h"
#include "spi.h"

extern xComPortHandle xSerialPort;
static QueueHandle_t myQueue = NULL;
static SemaphoreHandle_t mySemaphore = NULL;

void spi_master_init()
{
    DDRB |= (1 << PB2) | (1 << PB3) | (1 << PB5);
    DDRB &= ~(1 << PB4);
    PORTB |= (1 << PB2);
    SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR1) | (1 << SPR0);
}

void transmitInt(uint16_t value)
{
    spiSelect(1 << PB2);
    spiTransfer(0x01);
    spiTransfer((uint8_t)value);   
    spiTransfer((uint8_t)(value >> 8));
    spiDeselect(1 << PB2);
}

uint16_t receiveInt() {
    spiSelect(1 << PB2);
    spiTransfer(2);
    uint8_t byte1 = spiTransfer(0xff);
    uint8_t byte2 = spiTransfer(0xff);
    spiDeselect(1 << PB2);
    return (uint16_t)byte1 | (uint16_t)(byte2 << 8);
}

uint16_t numbers[] = {600, 32, 0, 400, 9999};
uint8_t idx = 0;

void receiveIntTask(void *pvParams)
{
    TickType_t delay = 1000 / (1000 / configTICK_RATE_HZ);
    TickType_t offset = 200 / (1000 / configTICK_RATE_HZ);
    
    vTaskDelay(offset);

    while (1)
    {
        uint16_t receivedValue = receiveInt();
        avrSerialxPrintf(&xSerialPort, "Received value from slave: %d\r\n", receivedValue);
        vTaskDelay(delay);
    }
}

void transmitIntTask(void *pvParams)
{
    TickType_t delay = 1000 / (1000 / configTICK_RATE_HZ);
    uint16_t len = sizeof(numbers) / sizeof(uint16_t);

    while (1)
    {
        transmitInt(numbers[idx % len]);
        idx++;
        vTaskDelay(delay);
    }
}

int main(void)
{
    spiBegin(PB2);
    spiSetClockDivider((1 << SPR1) | (1 << SPR0));

    xSerialPort = xSerialPortInitMinimal(
        USART0, 115200,
        portSERIAL_BUFFER_TX, portSERIAL_BUFFER_RX);

    myQueue = xQueueCreate(1, sizeof(uint8_t));
    mySemaphore = xSemaphoreCreateMutex();

    xTaskCreate(transmitIntTask, "Send Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(receiveIntTask, "Receive Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    vTaskStartScheduler();

    while (1)
    {
    }
}

void vApplicationIdleHook() {}
