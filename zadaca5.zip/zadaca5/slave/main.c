#define __AVR_ATmega328P__

#include <avr/io.h>
#include <avr/interrupt.h>
#include <serial.h>

void initializeSlave()
{
    DDRB = (1 << PB4);
    SPCR = (1 << SPE) | (1 << SPIE);
}

volatile uint8_t receivedBytes[8] = {0, 0, 0, 0, 0, 0, 0, 0};
volatile uint8_t byteIndex = 0;
volatile uint8_t byteCounter = 0;

uint16_t dataToSend[] = {1, 3, 10000, 6464, 500};
volatile uint8_t transmitBuffer[8] = {1, 0, 0, 0, 0, 0, 0, 0};
volatile uint8_t transmitCounter = 0;

ISR(SPI_STC_vect)
{
    uint8_t receivedByte = SPDR;   
    SPDR = transmitBuffer[byteCounter];
    receivedBytes[byteCounter] = receivedByte;
    byteCounter++;
}

int main(void)
{
    sei();
    uart_init();
    initializeSlave();

    uint16_t dataLength = sizeof(dataToSend) / sizeof(uint16_t); 

    while (1)
    {
        if (byteCounter > 2)
        {
            uint8_t firstByte = receivedBytes[0];
            uint8_t secondByte = receivedBytes[1];
            uint8_t thirdByte = receivedBytes[2];
            byteCounter = 0;
            if (firstByte == 1) {
                uint16_t value = secondByte | (uint16_t)(thirdByte) << 8;

                uart_putstr("Received value from master: ");
                uart_putint(value);
                uart_putstr("\r\n");
            } else if (firstByte == 0x02) {
                uart_putstr("Sent value to master: ");
                uart_putint(dataToSend[transmitCounter % dataLength]);
                uart_putstr("\r\n");
                transmitBuffer[0] = dataToSend[++transmitCounter % dataLength]; 
                transmitBuffer[1] = dataToSend[transmitCounter % dataLength] >> 8; 
            } else {
                receivedBytes[0] = 0;
                receivedBytes[1] = 0;
                receivedBytes[2] = 0;
            }
        }
    }
}
