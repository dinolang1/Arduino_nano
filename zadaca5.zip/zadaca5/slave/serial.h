#ifndef UART_SERIAL_H
#define UART_SERIAL_H

extern void uart_init();
extern void uart_putchar(char c);
extern void uart_putstr(char *data);
extern void uart_putint(signed long int n);

#endif // UART_SERIAL_H